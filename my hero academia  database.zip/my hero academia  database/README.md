
# PLUS ULTRA — My Hero Academia

Enciclopédia de personagens feita com HTML, CSS e JavaScript.

## Requisitos

- Visual Studio Code
- Navegador moderno
- Internet para carregar fontes e imagens externas

Não é necessário instalar Node.js ou outras bibliotecas.

## Como executar

1. Abra a pasta `my-hero-academia` no Visual Studio Code.
2. Confira se estes arquivos estão na mesma pasta:
   - `index.html`
   - `style.css`
   - `personagens.js`
   - `script.js`
   - `README.md`
3. Abra o arquivo `index.html` no navegador.

Opcionalmente, instale a extensão Live Server no VS Code,
clique com o botão direito em `index.html` e escolha
"Open with Live Server".

## Funcionalidades

- Pesquisa por nome, nome japonês e individualidade.
- Filtros por categoria e grupo.
- Ordenação alfabética.
- Cartões responsivos.
- Fichas com biografia, personalidade e habilidades.
- Modal com fechamento pelo botão ou pela tecla Escape.

## Personalizar imagens

O catálogo usa imagens provisórias do serviço placehold.co.
Para mostrar imagens reais, altere a função
imagemPersonagem() no arquivo script.js.

Utilize imagens próprias ou imagens cuja licença permita
o uso e a redistribuição. Verifique a licença de cada imagem.

## Adicionar personagens

No arquivo personagens.js, acrescente um objeto à lista
personagens, com um id único e os mesmos campos usados
pelos demais objetos.

## Criar um ZIP

No Windows:

1. Salve todos os arquivos.
2. Feche o editor se desejar.
3. Abra o Explorador de Arquivos.
4. Clique com o botão direito na pasta my-hero-academia.
5. Selecione "Compactar para arquivo ZIP" ou
   "Enviar para > Pasta compactada", conforme a versão do Windows.

O arquivo resultante poderá ser compartilhado e extraído
em outro computador.
