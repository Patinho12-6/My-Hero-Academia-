
"use strict";

const grade = document.getElementById("grade-personagens");
const busca = document.getElementById("busca");
const filtroCategoria = document.getElementById("filtro-categoria");
const filtroTurma = document.getElementById("filtro-turma");
const ordenacao = document.getElementById("ordenacao");
const contador = document.getElementById("contador-resultados");
const total = document.getElementById("total-personagens");
const semResultados = document.getElementById("sem-resultados");
const modal = document.getElementById("modal-personagem");
const detalhe = document.getElementById("detalhe-personagem");

total.textContent = personagens.length;

function escapar(texto) {
  return String(texto ?? "").replace(/[&<>"']/g, caractere => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[caractere]);
}

function imagemPersonagem(personagem) {
  // Imagem provisória externa com o nome do personagem.
  // Troque pelo endereço de uma imagem que você tenha
  // permissão para usar quando quiser personalizar o catálogo.
  return "https://placehold.co/600x800/202020/ffd43b?font=montserrat&text=" +
    encodeURIComponent(personagem.nome);
}

function iniciais(nome) {
  return nome.split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(parte => parte[0])
    .join("")
    .toUpperCase();
}

function obterPersonagensFiltrados() {
  const termo = busca.value.trim().toLocaleLowerCase("pt-BR");
  const categoria = filtroCategoria.value;
  const turma = filtroTurma.value;

  return personagens.filter(personagem => {
    const campos = [
      personagem.nome,
      personagem.japones,
      personagem.heroi,
      personagem.individualidade,
      personagem.grupo,
      personagem.categoria,
      personagem.personalidade,
      personagem.biografia
    ].join(" ").toLocaleLowerCase("pt-BR");

    const correspondeBusca = !termo || campos.includes(termo);
    const correspondeCategoria =
      categoria === "todos" || personagem.categoria === categoria;
    const correspondeTurma =
      turma === "todos" ||
      personagem.grupo === turma ||
      (turma === "Heróis profissionais" &&
        personagem.categoria === "Herói profissional") ||
      (turma === "Liga dos Vilões" &&
        personagem.grupo === "Liga dos Vilões") ||
      (turma === "U.A." &&
        (personagem.grupo === "U.A." ||
         personagem.grupo === "Classe 1-A" ||
         personagem.grupo === "Classe 1-B"));

    return correspondeBusca && correspondeCategoria && correspondeTurma;
  }).sort((a, b) => {
    const comparacao = a.nome.localeCompare(b.nome, "pt-BR");
    return ordenacao.value === "nome-desc" ? -comparacao : comparacao;
  });
}

function criarCartao(personagem, indice) {
  const card = document.createElement("button");
  card.type = "button";
  card.className = "character-card";
  card.style.animationDelay = `${Math.min(indice * 20, 300)}ms`;
  card.setAttribute("aria-label", `Abrir ficha de ${personagem.nome}`);

  const img = document.createElement("img");
  img.src = imagemPersonagem(personagem);
  img.alt = `Imagem de referência de ${personagem.nome}`;
  img.loading = "lazy";

  const areaImagem = document.createElement("div");
  areaImagem.className = "card-image";

  const tag = document.createElement("span");
  tag.className = "category-tag";
  tag.textContent = personagem.categoria;

  const fallback = document.createElement("span");
  fallback.className = "image-fallback";
  fallback.textContent = iniciais(personagem.nome);

  img.addEventListener("error", () => {
    img.hidden = true;
    fallback.hidden = false;
  });

  img.addEventListener("load", () => {
    img.hidden = false;
    fallback.hidden = true;
  });

  fallback.hidden = true;
  areaImagem.append(img, fallback, tag);

  const corpo = document.createElement("div");
  corpo.className = "card-body";
  corpo.innerHTML = `
    <span class="card-number">ARQUIVO #${String(indice + 1).padStart(3, "0")}</span>
    <h3>${escapar(personagem.nome)}</h3>
    <div class="japanese-name">${escapar(personagem.japones)}</div>
    <div class="quirk-label">INDIVIDUALIDADE</div>
    <div class="quirk-name">${escapar(personagem.individualidade)}</div>
    <div class="card-footer">
      <span>${escapar(personagem.grupo)}</span>
      <span>VER FICHA ↗</span>
    </div>
  `;

  card.append(areaImagem, corpo);
  card.addEventListener("click", () => abrirFicha(personagem.id));
  return card;
}

function renderizarCatalogo() {
  const filtrados = obterPersonagensFiltrados();
  grade.replaceChildren();

  const fragmento = document.createDocumentFragment();
  filtrados.forEach((personagem, indice) => {
    fragmento.appendChild(criarCartao(personagem, indice));
  });

  grade.appendChild(fragmento);
  contador.textContent =
    `${filtrados.length} personagem(ns) encontrado(s) de ${personagens.length}`;
  semResultados.hidden = filtrados.length !== 0;
}

function abrirFicha(id) {
  const personagem = personagens.find(item => item.id === id);
  if (!personagem) return;

  detalhe.innerHTML = `
    <div class="detail-layout">
      <div class="detail-image">
        <img
          src="${escapar(imagemPersonagem(personagem))}"
          alt="Imagem de referência de ${escapar(personagem.nome)}"
          onerror="this.style.display='none'"
        >
      </div>
      <article class="detail-content">
        <p class="eyebrow">${escapar(personagem.categoria)} · ${escapar(personagem.grupo)}</p>
        <h2>${escapar(personagem.nome)}</h2>
        <p>${escapar(personagem.japones)} · ${escapar(personagem.heroi)}</p>

        <div class="detail-meta">
          <div>
            <small>INDIVIDUALIDADE</small>
            <span>${escapar(personagem.individualidade)}</span>
          </div>
          <div>
            <small>AFILIAÇÃO / ORIGEM</small>
            <span>${escapar(personagem.origem)}</span>
          </div>
          <div>
            <small>PERSONALIDADE</small>
            <span>${escapar(personagem.personalidade)}</span>
          </div>
          <div>
            <small>HABILIDADES</small>
            <span>${escapar(personagem.habilidades)}</span>
          </div>
        </div>

        <h3>História e biografia</h3>
        <p>${escapar(personagem.biografia)}</p>

        <h3>Frase marcante</h3>
        <p class="detail-quote">“${escapar(personagem.frase)}”</p>
      </article>
    </div>
  `;

  if (!modal.open) modal.showModal();
}

[busca, filtroCategoria, filtroTurma, ordenacao].forEach(controle => {
  controle.addEventListener("input", renderizarCatalogo);
  controle.addEventListener("change", renderizarCatalogo);
});

document.getElementById("limpar-filtros").addEventListener("click", () => {
  busca.value = "";
  filtroCategoria.value = "todos";
  filtroTurma.value = "todos";
  ordenacao.value = "nome";
  renderizarCatalogo();
});

document.getElementById("fechar-modal").addEventListener("click", () => {
  modal.close();
});

modal.addEventListener("click", evento => {
  if (evento.target === modal) modal.close();
});

document.addEventListener("keydown", evento => {
  if (evento.key === "Escape" && modal.open) modal.close();
});

renderizarCatalogo();
